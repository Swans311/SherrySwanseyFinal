<?php 
    include (__DIR__.'/NavBar.php');

    if(isset($_GET['Totalsearch'])){
      $src=filter_input(INPUT_GET,'Totalsearch');
      $src= $_GET['Totalsearch'];
      header("Location: SearchResults.php?Totalsearch=".$src."");
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gourmandize | About Us</title>
</head>
<body>
    <div class="container gz-div-glow">
        <div class="container gz-div-inner mx-auto text-left p-5 text-white" style="font-family: textFont;">
            <div class="media mr-auto mb-5">
                <div>
                    <h4 style="text-decoration:underline;">Our Links</h4>
                    <a href="pdfs/proposal.pdf">Proposal Pdf</a>
                    <a href="https://marvelapp.com/project/5331792">Wireframe Prototypes (Sorry I don't want to pay for these)</a>
                    <a href="pdfs/TechSpec.pdf">Technical Design Pdf</a>
                    <p>Relationship Design: </p>
                    <a href="pdfs/Screenshots.pdf">Screenshots</a>
                    <a href="pdfs/Presentation.pdf">Presentation PowerPoint</a>
                    <p>Zip File of Source Code: </p>
                    <a href="https://github.com/Swans311/SherrySwanseyFinal"> Github Link</a>
                </div>
            </div>
        </div>
    </div>
</body>
<footer style="bottom:0; width:100%;">
  <br/>
  <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.9); color:#ff3300; font-size:16px">
    © 2021 Copyright:
    <a class="text-blue" href="AboutUs.php">About Us</a>
  </div>
  </footer>
</html>